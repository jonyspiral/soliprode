---
name: Athletic Social
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#434653'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#737784'
  outline-variant: '#c3c6d5'
  surface-tint: '#2559bd'
  primary: '#00327d'
  on-primary: '#ffffff'
  primary-container: '#0047ab'
  on-primary-container: '#a5bdff'
  inverse-primary: '#b1c5ff'
  secondary: '#0c6780'
  on-secondary: '#ffffff'
  secondary-container: '#9ae1ff'
  on-secondary-container: '#09657f'
  tertiary: '#705d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c9a900'
  on-tertiary-container: '#4c3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419e'
  secondary-fixed: '#baeaff'
  secondary-fixed-dim: '#89d0ed'
  on-secondary-fixed: '#001f29'
  on-secondary-fixed-variant: '#004d62'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-xl:
    fontFamily: Archivo Narrow
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Archivo Narrow
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Archivo Narrow
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Archivo Narrow
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 16px
  gutter: 12px
  stack-sm: 4px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
This design system captures the electric atmosphere of a world-class stadium. It is built for a high-energy sports community where competition meets camaraderie. The aesthetic is **Modern Sports**, blending professional performance metrics with the vibrant, celebratory spirit of global football culture. 

The UI should feel authoritative yet inviting, utilizing high-contrast elements to drive action and community engagement. Visuals are grounded in "pitch-side" realism, using subtle textures and bold structural lines to evoke the feeling of a tactical chalkboard and the texture of the turf. It is a mobile-first experience designed for quick interactions during the heat of a match.

## Colors
The palette is rooted in the "Mundial Energy" narrative, utilizing a triadic scheme that feels classic yet high-octane.

- **Deep Stadium Blue (#0047AB):** The primary anchor. It represents trust, the night sky over a stadium, and professional sportsmanship.
- **Sky Celeste (#87CEEB):** Used for interactive elements, hover states, and secondary actions, providing a breath of fresh air against the heavy blue.
- **Trophy Gold (#FFD700):** Reserved strictly for high-priority alerts, achievements, rankings, and CTA accents to signify victory.
- **Pure White (#FFFFFF):** The primary canvas color to ensure maximum legibility and a clean, "fresh kit" feel.

## Typography
The typography strategy employs a "High-Low" contrast system. 

**Archivo Narrow** is used for headlines to mimic the condensed, impactful type found on player jerseys and stadium scoreboards. It communicates urgency and scale. 

**Inter** handles all functional and body text. Its neutral, systematic nature ensures that dense data (like league tables or match stats) remains highly legible on mobile devices. Use uppercase labels with increased letter spacing for navigation and metadata to reinforce the athletic aesthetic.

## Layout & Spacing
This design system utilizes a **Mobile-First Fluid Grid** based on an 8px square rhythm. 

- **Grid:** A 4-column grid for mobile, scaling to 12 columns for desktop. 
- **Margins:** A 16px safety margin on mobile to ensure content doesn't feel cramped against the screen edges.
- **Gutters:** Tight 12px gutters between cards to create a dense, "packed-stadium" energy while maintaining visual separation.
- **Pitch Textures:** Backgrounds should utilize a very subtle, low-opacity (2-3%) geometric pattern overlay that mimics the mowed patterns of a football field.

## Elevation & Depth
Depth in this design system is achieved through **Bold Outlines** and **Tonal Layering** rather than soft shadows.

- **Surface Tiers:** The primary background is white. Secondary surfaces (like search bars or inactive tabs) use a very light cool gray (#F1F4F9).
- **Hard Borders:** Components use 1.5px or 2px solid borders in Primary Blue or a light Silver-Gray. This mimics the structured markings of a sports field.
- **Focus States:** Active elements utilize a Sky Celeste outer glow (0px 0px 8px) to simulate stadium lights, creating a "shining" effect on selected content.

## Shapes
The shape language is disciplined and geometric. While the roundedness is set to **Soft (Level 1)**, the primary goal is to maintain a professional, high-performance look. 

- **Containers:** 4px radius for standard cards and inputs to keep them looking sharp and fast.
- **Buttons:** Slightly more rounded (8px) to provide a friendly, tactile target for thumbs on mobile.
- **Icons:** Use sharp, linear icons with a consistent 2px stroke weight to match the border language of the components.

## Components
- **Action Buttons:** Primary buttons are Solid Deep Blue with White text. Secondary buttons are outlined in Deep Blue. "Win" or "Success" actions use Trophy Gold backgrounds.
- **Match Cards:** Use a 1.5px border. The header of the card should be a solid Blue bar with White condensed type for the "Match Minute" or "League Name."
- **Leaderboard Lists:** Use zebra-striping with #F1F4F9 and high-contrast numbers for rankings. The "Top 3" should feature Trophy Gold accents.
- **Score Chips:** Small, pill-shaped badges with high-contrast backgrounds (e.g., Sky Celeste background for "Live" status).
- **Input Fields:** Clear, white backgrounds with a bold bottom-border focus state. Labels should always be visible in uppercase Inter.
- **Sports Icons:** Custom iconography should be used for different match events (whistle, card, goal, substitution), rendered in a uniform stroke style.